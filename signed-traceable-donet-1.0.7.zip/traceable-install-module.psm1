﻿#Requires -RunAsAdministrator

$env:SystemDirectory = [Environment]::SystemDirectory

$IIS_Config = $env:SystemDirectory + "\inetsrv\config\applicationhost.config"
$appCmd = $env:SystemDirectory + "\inetsrv\appcmd.exe"

function Check-TPA-Endpoint() {
    $TPAEndpoint = Read-Host -Prompt 'TPA-endpoint'
    [System.Environment]::SetEnvironmentVariable('TA_ENDPOINT', $TPAEndpoint, [System.EnvironmentVariableTarget]::Machine)
}

function Check-TPA-Certificate() {
    $TPACert = Read-Host -Prompt 'Enter TPA-Certificate Path (if not set TA_CA_CERT_VERIFY has to be set to 0)'
    [System.Environment]::SetEnvironmentVariable('TA_CA_CERT', $TPACert, [System.EnvironmentVariableTarget]::Machine)
}

function Check-Service-Host() {
    $host = Read-Host -Prompt 'Enter service name suffix. This will be appended to every discovered service name.'
    [System.Environment]::SetEnvironmentVariable('TRACEABLE_SERVICE_SUFFIX', $host, [System.EnvironmentVariableTarget]::Machine)
}

function Check-SSL-Verify() {
    $bool = Read-Host -Prompt 'Enable server side ssl certificate verification ? Enter 1 to enable, 0 to disable'
    [System.Environment]::SetEnvironmentVariable('TA_CA_CERT_VERIFY', $bool, [System.EnvironmentVariableTarget]::Machine)
}

function Get-Temp-Directory() {
    $temp = $env:TEMP
    if (-not (Test-Path $temp)) {
        New-Item -ItemType Directory -Force -Path $temp | Out-Null
    }
    return $temp
}

function Get-Current-InstallDir() {
    return [System.Environment]::GetEnvironmentVariable("TRACEABLE_AGENT_INSTALL_DIR", [System.EnvironmentVariableTarget]::Machine)
}

function Reset-IIS() {    
    Start-Process "iisreset.exe" -NoNewWindow -Wait
}

function Get-CLIInstallDir-From-InstallDir([string]$InstallDir) {
    $dir = "Traceable DotNetAgent"
    
    if ($InstallDir -eq "<auto>") {
        return (Join-Path $Env:ProgramFiles $dir)
    }
    elseif (Test-Path $InstallDir -IsValid) {
        return $InstallDir
    }

    throw "Invalid install directory provided '$InstallDir'"
}

function Prepare-Install-Directory([string]$InstallDir) {
    if (Test-Path $InstallDir) {
        # Cleanup old directory
        Remove-Item -LiteralPath $InstallDir -Force -Recurse
    }
    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
}

function Install-Agent() {
    param(
        [string]$InstallDir = "<auto>"
    )

    $installDir = Get-CLIInstallDir-From-InstallDir $InstallDir
    $dlPath = $null
    $dll = $null

    try {
        $dlPath = $PSScriptRoot
        $dll = $dlPath + "/TraceableIISModule.dll"
        $dll32bit = $dlPath + "/TraceableIISModule-x86.dll"
        Prepare-Install-Directory $installDir

        Copy-Item $dll -Destination $InstallDir
        Copy-Item $dll32bit -Destination $InstallDir

        [System.Environment]::SetEnvironmentVariable('TRACEABLE_AGENT_INSTALL_DIR', $installDir, [System.EnvironmentVariableTarget]::Machine)

        Write-Output "Installed Traceable IIS Agent Successfully"
    } 
    catch {
        $message = $_
        Write-Error "Could not install Traceable IIS Agent! $message"
    } 
}

function Uninstall-Agent() {
    Unregister-Agent
    $installDir = Get-Current-InstallDir
    if (-not $installDir) {
        throw "Traceable IIS Agent is already removed."
    }
    Remove-Item -LiteralPath $installDir -Force -Recurse
    [System.Environment]::SetEnvironmentVariable('TRACEABLE_AGENT_INSTALL_DIR', $null, [System.EnvironmentVariableTarget]::Machine)

    Write-Output "Traceable IIS Agent uninstall successful"
}

function Update-WebModuleConfiguration {
    param(
        [string]$ModuleName,
        [string]$PreCondition,
        [string]$Website
    )

    if (-not $Website) {
        $psPath = 'MACHINE/WEBROOT/APPHOST'
    } else {
        $psPath = "IIS:\Sites\$Website"
    }

    $filter = "//modules/add[@name='$ModuleName']"

    if ((Get-WebConfiguration -PSPath $psPath -Filter $filter -ErrorAction SilentlyContinue) -ne $null) {
        # Module configuration exists, update it
        Set-WebConfigurationProperty -PSPath $psPath -Filter $filter -Name "preCondition" -Value $PreCondition
        Write-Output "Configuration updated for $ModuleName with precondition $PreCondition"
    } else {
        # Module configuration does not exist, add it
        Add-WebConfiguration -PSPath $psPath -Filter "//modules" -Value @{name=$ModuleName; preCondition=$PreCondition}
        Write-Output "Configuration added for $ModuleName with precondition $PreCondition"
    }
}

function Add-AppInstrumentation() {
    param(
        [Parameter(Mandatory = $true)]
        [string]$website
    )

    $test = [System.Environment]::GetEnvironmentVariable('GLOBAL_MODULE_REGISTERED', 'Machine')
    if ($test -ne '1') {
        $lockInfo = Get-WebConfigurationLock -Filter "//modules"
        if ($lockInfo) {
            Write-Output "Modules section is locked for websites. Unlock it before instrumenting."
            return
        }
        $websiteLockInfo = Get-WebConfigurationLock -PSPath "IIS:\Sites\$website" -Filter "//modules"
        if ($lockInfo) {
            Write-Output "Modules section is locked for website $website. Unlock it before instrumenting."
            return
        }

        Update-WebModuleConfiguration -ModuleName "TraceableDotNetAgent" -PreCondition "bitness64" -Website $website
        Update-WebModuleConfiguration -ModuleName "TraceableDotNetAgent32bit" -PreCondition "bitness32" -Website $website
        Write-Output "IIS is instrumented for website $website"
    }
    else {
        Write-Output "Global instrumentation already exists. Remove it before instrumenting website"
    }
}

function Remove-AppInstrumentation() {
    param(
        [Parameter(Mandatory = $true)]
        [string]$website
    )
    Clear-WebConfiguration -PSPath "IIS:\Sites\$Website" -Filter "//modules/add[@name='TraceableDotNetAgent']"
    Clear-WebConfiguration -PSPath "IIS:\Sites\$Website" -Filter "//modules/add[@name='TraceableDotNetAgent32bit']"
    Write-Output "IIS instrumentation is removed for website $website"
}

function Add-GlobalInstrumentation() {
    $test = [System.Environment]::GetEnvironmentVariable('GLOBAL_MODULE_REGISTERED', 'Machine')
    if ($test -ne '1') {
        Update-WebModuleConfiguration -ModuleName "TraceableDotNetAgent" -PreCondition "bitness64"
        Update-WebModuleConfiguration -ModuleName "TraceableDotNetAgent32bit" -PreCondition "bitness32"
        [System.Environment]::SetEnvironmentVariable('GLOBAL_MODULE_REGISTERED', 1, [System.EnvironmentVariableTarget]::Machine)

        Write-Output "IIS is instrumented globally"
    }
    else {
        Write-Output "Global instrumentation already exists"
    }
}

function Remove-GlobalInstrumentation() {
    $test = [System.Environment]::GetEnvironmentVariable('GLOBAL_MODULE_REGISTERED', 'Machine')
    if ($test -ne '1') {
        Write-Output "Global instrumentation doesn't exist"
        return
    }

    Clear-WebConfiguration -PSPath 'MACHINE/WEBROOT/APPHOST' -Filter "//modules/add[@name='TraceableDotNetAgent']"
    Clear-WebConfiguration -PSPath 'MACHINE/WEBROOT/APPHOST' -Filter "//modules/add[@name='TraceableDotNetAgent32bit']"

    [System.Environment]::SetEnvironmentVariable('GLOBAL_MODULE_REGISTERED', 0  , [System.EnvironmentVariableTarget]::Machine)

    Write-Output "Global instrumentation is removed now."
}

function Register-Traceable-DotNetAgent-IIS([string]$InstallDir) {
    $test = [System.Environment]::GetEnvironmentVariable('TRACEABLE_AGENT_AS_GLOBAL_MODULE', 'Machine')
    $installDir = Get-Current-InstallDir
    $dll = $installDir + "\TraceableIISModule.dll"
    $dll32bit = $installDir + "\TraceableIISModule-x86.dll"

    $existing64bit = & $appCmd --% list config -section:system.webServer/globalModules | Select-String "TraceableDotNetAgent"
    $existing32bit = & $appCmd --% list config -section:system.webServer/globalModules | Select-String "TraceableDotNetAgent32bit"
    
    Write-Output $dll32bit

    if ($test -ne '1') {
        $env:dll = $dll
        $env:dll32bit = $dll32bit

        if ($existing64bit) {
            Write-Output "Found an existing 64 bit config overwritting it."
            & $appCmd --% clear config -section:system.webServer/globalModules /"[name='TraceableDotNetAgent',preCondition='bitness64']" /commit:apphost
        }
        if ($existing32bit) {
            Write-Output "Found an existing 32 bit config overwritting it."
            & $appCmd --% clear config -section:system.webServer/globalModules /"[name='TraceableDotNetAgent32bit',preCondition='bitness32']" /commit:apphost
        }
           
        & $appCmd --% set config -section:system.webServer/globalModules /+"[name='TraceableDotNetAgent',image='%dll%',preCondition='bitness64']" /commit:apphost
        & $appCmd --% set config -section:system.webServer/globalModules /+"[name='TraceableDotNetAgent32bit',image='%dll32bit%',preCondition='bitness32']" /commit:apphost

        [System.Environment]::SetEnvironmentVariable('TRACEABLE_AGENT_AS_GLOBAL_MODULE', 1, [System.EnvironmentVariableTarget]::Machine)

        Write-Output "Traceable IIS Agent added as IIS native module"
    } else {
        Write-Output "Traceable IIS Agent already exists as a native module"
    }
}

function Register-Agent() {
    $installDir = Get-Current-InstallDir
    Write-Output $installDir
    if (-not $installDir) {
        throw "Traceable DotNetAgent must be setup first. Run 'Install-Agent' to setup Traceable IIS Agent"
    }

    if ($installDir -notlike "$env:ProgramFiles\*") {
        Write-Warning "Traceable IIS Agent is installed to custom path. Make sure that IIS user has access to the path."
    }

    $tempDir = Get-Temp-Directory
    Copy-Item $IIS_Config -Destination $tempDir
    Write-Output "IIS config has been backed up to temp dir:" + $tempDir
    Check-TPA-Endpoint
    Check-TPA-Certificate
    Check-Service-Host
    Check-SSL-Verify
    Register-Traceable-DotNetAgent-IIS -InstallDir $installDir

    Reset-IIS
}

function Unregister-Agent() {
    $test = [System.Environment]::GetEnvironmentVariable('TRACEABLE_AGENT_AS_GLOBAL_MODULE', 'Machine')
    $installDir = Get-Current-InstallDir
    if ($test -eq '1') {
        $env:dll = $null
        & $appCmd --% clear config -section:system.webServer/globalModules /"[name='TraceableDotNetAgent',preCondition='bitness64']" /commit:apphost
        $env:dll32bit = $null
        & $appCmd --% clear config -section:system.webServer/globalModules /"[name='TraceableDotNetAgent32bit',preCondition='bitness32']" /commit:apphost
        [System.Environment]::SetEnvironmentVariable('TRACEABLE_AGENT_AS_GLOBAL_MODULE', 0  , [System.EnvironmentVariableTarget]::Machine)
        [System.Environment]::SetEnvironmentVariable("TA_ENDPOINT", $null , [System.EnvironmentVariableTarget]::Machine)
        [System.Environment]::SetEnvironmentVariable("TA_CA_CERT", $null , [System.EnvironmentVariableTarget]::Machine)
        [System.Environment]::SetEnvironmentVariable("TA_CA_CERT_VERIFY", $null , [System.EnvironmentVariableTarget]::Machine)
        [System.Environment]::SetEnvironmentVariable("TRACEABLE_SERVICE_SUFFIX", $null , [System.EnvironmentVariableTarget]::Machine)
        [System.Environment]::SetEnvironmentVariable('GLOBAL_MODULE_REGISTERED', $null  , [System.EnvironmentVariableTarget]::Machine)

        Write-Output "Removed DotNetAgent as native module from iis"
        Reset-IIS
    }
    else {
        Write-Output "Traceable IIS module doesn't exist as native module"
    }
}

Export-ModuleMember -Function Install-Agent
Export-ModuleMember -Function Uninstall-Agent
Export-ModuleMember -Function Register-Agent
Export-ModuleMember -Function Unregister-Agent
Export-ModuleMember -Function Add-GlobalInstrumentation
Export-ModuleMember -Function Remove-GlobalInstrumentation
Export-ModuleMember -Function Add-AppInstrumentation
Export-ModuleMember -Function Remove-AppInstrumentation

# SIG # Begin signature block
# MIIokAYJKoZIhvcNAQcCoIIogTCCKH0CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCC18jis88BS8bmz
# EGmV5dtH5pShjv3YQK1lauWWtJ3Tz6CCDf0wggawMIIEmKADAgECAhAIrUCyYNKc
# TJ9ezam9k67ZMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0z
# NjA0MjgyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDVtC9C0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0
# JAfhS0/TeEP0F9ce2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJr
# Q5qZ8sU7H/Lvy0daE6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhF
# LqGfLOEYwhrMxe6TSXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+F
# LEikVoQ11vkunKoAFdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh
# 3K3kGKDYwSNHR7OhD26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJ
# wZPt4bRc4G/rJvmM1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQay
# g9Rc9hUZTO1i4F4z8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbI
# YViY9XwCFjyDKK05huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchAp
# QfDVxW0mdmgRQRNYmtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRro
# OBl8ZhzNeDhFMJlP/2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IB
# WTCCAVUwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+
# YXsIiGX0TkIwHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAC
# hjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAED
# MAgGBmeBDAEEATANBgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql
# +Eg08yy25nRm95RysQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFF
# UP2cvbaF4HZ+N3HLIvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1h
# mYFW9snjdufE5BtfQ/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3Ryw
# YFzzDaju4ImhvTnhOE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5Ubdld
# AhQfQDN8A+KVssIhdXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw
# 8MzK7/0pNVwfiThV9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnP
# LqR0kq3bPKSchh/jwVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatE
# QOON8BUozu3xGFYHKi8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bn
# KD+sEq6lLyJsQfmCXBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQji
# WQ1tygVQK+pKHJ6l/aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbq
# yK+p/pQd52MbOoZWeE4wggdFMIIFLaADAgECAhAFbBRf7feWvvlLYD4V9g1uMA0G
# CSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjQwMTEyMDAwMDAwWhcNMjUwMTEy
# MjM1OTU5WjCBzTETMBEGCysGAQQBgjc8AgEDEwJVUzEZMBcGCysGAQQBgjc8AgEC
# EwhEZWxhd2FyZTEdMBsGA1UEDwwUUHJpdmF0ZSBPcmdhbml6YXRpb24xEDAOBgNV
# BAUTBzcwODIxMjcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpDYWxpZm9ybmlhMRYw
# FAYDVQQHEw1TYW4gRnJhbmNpc2NvMRcwFQYDVQQKEw5UcmFjZWFibGUgSW5jLjEX
# MBUGA1UEAxMOVHJhY2VhYmxlIEluYy4wggGiMA0GCSqGSIb3DQEBAQUAA4IBjwAw
# ggGKAoIBgQCwbmxHLhqK9W6YupDNhu8bo2mRiNZnqHiijE8cWQlrCUVtQBr4r8pi
# f3Mf2WpPKfsoSbDaAM7f0PvpXQT0RnNZgQb3+gywsw6OCGd88N/Quyy90QTvNzRw
# aT3TeG2UT1Zo3zdw3IQBBHQGjaCSkncQzHqZhMof/iuQTA5jpXkf+8zoFCwwRHLd
# Meu2F3nel9b7OG7lTdQEt/vbxRVQb+wuFAp2dKFWDFgrlM8NMN2pDaR5gQgPuoDp
# 9W8XgPKTGs5O0yl3z2zmBWSFR+1SPzVyokSAhQpSTWF7GeUFr+iEu+XNozl34pQI
# cU200KI15eedsPOSZNR5UtcmpUEEKNCNMsbGM05fyMhMPkIuLAP9+vguSw+/srR9
# KGEJYgef4ZaWNo6vBev083IYYzTW+E3rcSEvf4nIB2Skt9Pt0OV6eMk8wJDu+dVq
# Xu5Xqc7k8cPkrRZ5VfCja2/0GIQx0PN8bPM9CuszLaAplYyPPdmaaNoXnCfOZgEI
# N5Sw9TkGozsCAwEAAaOCAgIwggH+MB8GA1UdIwQYMBaAFGg34Ou2O/hfEYb7/mF7
# CIhl9E5CMB0GA1UdDgQWBBQPcOoQBx4IhjnQSS9CJAg/UA8JEDA9BgNVHSAENjA0
# MDIGBWeBDAEDMCkwJwYIKwYBBQUHAgEWG2h0dHA6Ly93d3cuZGlnaWNlcnQuY29t
# L0NQUzAOBgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwgbUGA1Ud
# HwSBrTCBqjBToFGgT4ZNaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0MjAyMUNBMS5jcmwwU6BR
# oE+GTWh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENv
# ZGVTaWduaW5nUlNBNDA5NlNIQTM4NDIwMjFDQTEuY3JsMIGUBggrBgEFBQcBAQSB
# hzCBhDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMFwGCCsG
# AQUFBzAChlBodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVz
# dGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNydDAJBgNVHRME
# AjAAMA0GCSqGSIb3DQEBCwUAA4ICAQBrTEautRO1ungQFc1DhVvk6OODU1A+sx+J
# Ol9Vv08OhH/JoF+/mf4lgC+Zchh6bRFjtVDmxQ4lI3Mq86XYCUOUP0C6b7ZJNKLZ
# 8FKgCGnXAHjnaR7ZvBEkOBR4AG9JvZSm5T9Ga8C+SI54+LUEtj008rQyznRBGGCO
# aW3LaEF4cfS8kLGvA1p4Oc68Lpf/tIZLbkVHU4/CpQxMtkM5I65BcR0y5SByhvCR
# F3EkCPJr+KEUy2M8ASFvBdOXRr/WF3VHCoL2tPL97kDYudxddmrEUyFKpcGS2wPG
# xJyO6DLRm+fhVgIdB+80i2TrRPpM6quXmQ/MViioO5TCM8R8SkBndMB/ju5B91Ed
# D/kPWumxpmWpigs+e/hz5OrNaU01zeWQqKXRNKthrxi7AGf/9VK3shwEfaJbtHv9
# LXmw8ZfbZOh67E/2poTNKhZW9cDnQgSFQRP5RvG8ObAfuI+fmrE4pXdqNlv2QXU1
# Sl5PTtitCz+iZxZljO0i2+doqzKehyZgNs/Z7cOtaDoKACP1gldem6I784b00WS0
# eSOFkWhJ5B7zE4dViu3jH+aKR7QkOCDL9B27qc5++ohZ0yDoEC3VkpmNcEVxITd/
# lwsQEqrnDalrHx7uUSoAEiReGB+jxSvEKssKtkOr6zGE9SPieIfN27sWxHemzO4s
# xnQ72KOlpTGCGekwghnlAgEBMH0waTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRp
# Z2lDZXJ0LCBJbmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IENvZGUg
# U2lnbmluZyBSU0E0MDk2IFNIQTM4NCAyMDIxIENBMQIQBWwUX+33lr75S2A+FfYN
# bjANBglghkgBZQMEAgEFAKB8MBAGCisGAQQBgjcCAQwxAjAAMBkGCSqGSIb3DQEJ
# AzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8G
# CSqGSIb3DQEJBDEiBCC+oenLrYI/eOkKm4Mb3D7gCLern1ezvtMBanasSZ+EwjAN
# BgkqhkiG9w0BAQEFAASCAYA6el/y8tu/DSfu7deuj7mnv7ekbEA4A2312JMaYGU9
# JTQILWprmo5761QwUoiEUNfa2wK8/8fs2Lsx/PQMf28ycnBS3MecBmDC9q4qSLhS
# Yn/dcM8DpkLZwlLv3jVJ1YbPHkECibPrC1WE9g1RMLISMrKycsRo16ESeGU41iBt
# W+KOAQeuiH9j6A6WZ8yhc0+s1BFjJaKdpTS0ItkIqArUVJsK1yrGSloeepUqycTg
# 16YHpI76DXw++H27xZ5QPUTIyctuV3TGW2+CCVzD1iRciYNYZA48O0NLcY6tqxpR
# 4KEEDlo+fhTqCkOZEaHgCetmBfPaAZQQGj3vqMWC51lu8zZRo20A01jDn4s2eHKb
# 0WiTvp9QL1uSayUr6VGBFbOjlj0ymx6CyfjcfYIS1oaBz6r2CjuFMZp/M4txdkjp
# hGMFk0hYKHD7xV/HjwTs7heK2mY08aDG4C2AvYqP/+adkspKKWY0oNu8OANq4SSv
# H4AYcpqe7VTTBLzmdEvS8WShghc/MIIXOwYKKwYBBAGCNwMDATGCFyswghcnBgkq
# hkiG9w0BBwKgghcYMIIXFAIBAzEPMA0GCWCGSAFlAwQCAQUAMHcGCyqGSIb3DQEJ
# EAEEoGgEZjBkAgEBBglghkgBhv1sBwEwMTANBglghkgBZQMEAgEFAAQgSi8iErSl
# csqioOFQOj1dlCCrOGNV8NPXnt+knDMXN7YCEAcnhvs6bGfWEdIff2VxUmkYDzIw
# MjQwMTE4MDkzMjE0WqCCEwkwggbCMIIEqqADAgECAhAFRK/zlJ0IOaa/2z9f5WEW
# MA0GCSqGSIb3DQEBCwUAMGMxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2Vy
# dCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNI
# QTI1NiBUaW1lU3RhbXBpbmcgQ0EwHhcNMjMwNzE0MDAwMDAwWhcNMzQxMDEzMjM1
# OTU5WjBIMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xIDAe
# BgNVBAMTF0RpZ2lDZXJ0IFRpbWVzdGFtcCAyMDIzMIICIjANBgkqhkiG9w0BAQEF
# AAOCAg8AMIICCgKCAgEAo1NFhx2DjlusPlSzI+DPn9fl0uddoQ4J3C9Io5d6Oyqc
# Z9xiFVjBqZMRp82qsmrdECmKHmJjadNYnDVxvzqX65RQjxwg6seaOy+WZuNp52n+
# W8PWKyAcwZeUtKVQgfLPywemMGjKg0La/H8JJJSkghraarrYO8pd3hkYhftF6g1h
# bJ3+cV7EBpo88MUueQ8bZlLjyNY+X9pD04T10Mf2SC1eRXWWdf7dEKEbg8G45lKV
# tUfXeCk5a+B4WZfjRCtK1ZXO7wgX6oJkTf8j48qG7rSkIWRw69XloNpjsy7pBe6q
# 9iT1HbybHLK3X9/w7nZ9MZllR1WdSiQvrCuXvp/k/XtzPjLuUjT71Lvr1KAsNJvj
# 3m5kGQc3AZEPHLVRzapMZoOIaGK7vEEbeBlt5NkP4FhB+9ixLOFRr7StFQYU6mII
# E9NpHnxkTZ0P387RXoyqq1AVybPKvNfEO2hEo6U7Qv1zfe7dCv95NBB+plwKWEwA
# PoVpdceDZNZ1zY8SdlalJPrXxGshuugfNJgvOuprAbD3+yqG7HtSOKmYCaFxsmxx
# rz64b5bV4RAT/mFHCoz+8LbH1cfebCTwv0KCyqBxPZySkwS0aXAnDU+3tTbRyV8I
# pHCj7ArxES5k4MsiK8rxKBMhSVF+BmbTO77665E42FEHypS34lCh8zrTioPLQHsC
# AwEAAaOCAYswggGHMA4GA1UdDwEB/wQEAwIHgDAMBgNVHRMBAf8EAjAAMBYGA1Ud
# JQEB/wQMMAoGCCsGAQUFBwMIMCAGA1UdIAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG
# /WwHATAfBgNVHSMEGDAWgBS6FtltTYUvcyl2mi91jGogj57IbzAdBgNVHQ4EFgQU
# pbbvE+fvzdBkodVWqWUxo97V40kwWgYDVR0fBFMwUTBPoE2gS4ZJaHR0cDovL2Ny
# bDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRp
# bWVTdGFtcGluZ0NBLmNybDCBkAYIKwYBBQUHAQEEgYMwgYAwJAYIKwYBBQUHMAGG
# GGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBYBggrBgEFBQcwAoZMaHR0cDovL2Nh
# Y2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0UlNBNDA5NlNIQTI1
# NlRpbWVTdGFtcGluZ0NBLmNydDANBgkqhkiG9w0BAQsFAAOCAgEAgRrW3qCptZgX
# vHCNT4o8aJzYJf/LLOTN6l0ikuyMIgKpuM+AqNnn48XtJoKKcS8Y3U623mzX4WCc
# K+3tPUiOuGu6fF29wmE3aEl3o+uQqhLXJ4Xzjh6S2sJAOJ9dyKAuJXglnSoFeoQp
# mLZXeY/bJlYrsPOnvTcM2Jh2T1a5UsK2nTipgedtQVyMadG5K8TGe8+c+njikxp2
# oml101DkRBK+IA2eqUTQ+OVJdwhaIcW0z5iVGlS6ubzBaRm6zxbygzc0brBBJt3e
# WpdPM43UjXd9dUWhpVgmagNF3tlQtVCMr1a9TMXhRsUo063nQwBw3syYnhmJA+rU
# kTfvTVLzyWAhxFZH7doRS4wyw4jmWOK22z75X7BC1o/jF5HRqsBV44a/rCcsQdCa
# M0qoNtS5cpZ+l3k4SF/Kwtw9Mt911jZnWon49qfH5U81PAC9vpwqbHkB3NpE5jre
# ODsHXjlY9HxzMVWggBHLFAx+rrz+pOt5Zapo1iLKO+uagjVXKBbLafIymrLS2Dq4
# sUaGa7oX/cR3bBVsrquvczroSUa31X/MtjjA2Owc9bahuEMs305MfR5ocMB3CtQC
# 4Fxguyj/OOVSWtasFyIjTvTs0xf7UGv/B3cfcZdEQcm4RtNsMnxYL2dHZeUbc7aZ
# +WssBkbvQR7w8F/g29mtkIBEr4AQQYowggauMIIElqADAgECAhAHNje3JFR82Ees
# /ShmKl5bMA0GCSqGSIb3DQEBCwUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxE
# aWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMT
# GERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMjAzMjMwMDAwMDBaFw0zNzAz
# MjIyMzU5NTlaMGMxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5j
# LjE7MDkGA1UEAxMyRGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBU
# aW1lU3RhbXBpbmcgQ0EwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDG
# hjUGSbPBPXJJUVXHJQPE8pE3qZdRodbSg9GeTKJtoLDMg/la9hGhRBVCX6SI82j6
# ffOciQt/nR+eDzMfUBMLJnOWbfhXqAJ9/UO0hNoR8XOxs+4rgISKIhjf69o9xBd/
# qxkrPkLcZ47qUT3w1lbU5ygt69OxtXXnHwZljZQp09nsad/ZkIdGAHvbREGJ3Hxq
# V3rwN3mfXazL6IRktFLydkf3YYMZ3V+0VAshaG43IbtArF+y3kp9zvU5EmfvDqVj
# bOSmxR3NNg1c1eYbqMFkdECnwHLFuk4fsbVYTXn+149zk6wsOeKlSNbwsDETqVcp
# licu9Yemj052FVUmcJgmf6AaRyBD40NjgHt1biclkJg6OBGz9vae5jtb7IHeIhTZ
# girHkr+g3uM+onP65x9abJTyUpURK1h0QCirc0PO30qhHGs4xSnzyqqWc0Jon7ZG
# s506o9UD4L/wojzKQtwYSH8UNM/STKvvmz3+DrhkKvp1KCRB7UK/BZxmSVJQ9FHz
# NklNiyDSLFc1eSuo80VgvCONWPfcYd6T/jnA+bIwpUzX6ZhKWD7TA4j+s4/TXkt2
# ElGTyYwMO1uKIqjBJgj5FBASA31fI7tk42PgpuE+9sJ0sj8eCXbsq11GdeJgo1gJ
# ASgADoRU7s7pXcheMBK9Rp6103a50g5rmQzSM7TNsQIDAQABo4IBXTCCAVkwEgYD
# VR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUuhbZbU2FL3MpdpovdYxqII+eyG8w
# HwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGG
# MBMGA1UdJQQMMAoGCCsGAQUFBwMIMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcw
# AYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8v
# Y2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBD
# BgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNl
# cnRUcnVzdGVkUm9vdEc0LmNybDAgBgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgB
# hv1sBwEwDQYJKoZIhvcNAQELBQADggIBAH1ZjsCTtm+YqUQiAX5m1tghQuGwGC4Q
# TRPPMFPOvxj7x1Bd4ksp+3CKDaopafxpwc8dB+k+YMjYC+VcW9dth/qEICU0MWfN
# thKWb8RQTGIdDAiCqBa9qVbPFXONASIlzpVpP0d3+3J0FNf/q0+KLHqrhc1DX+1g
# tqpPkWaeLJ7giqzl/Yy8ZCaHbJK9nXzQcAp876i8dU+6WvepELJd6f8oVInw1Ypx
# dmXazPByoyP6wCeCRK6ZJxurJB4mwbfeKuv2nrF5mYGjVoarCkXJ38SNoOeY+/um
# nXKvxMfBwWpx2cYTgAnEtp/Nh4cku0+jSbl3ZpHxcpzpSwJSpzd+k1OsOx0ISQ+U
# zTl63f8lY5knLD0/a6fxZsNBzU+2QJshIUDQtxMkzdwdeDrknq3lNHGS1yZr5Dhz
# q6YBT70/O3itTK37xJV77QpfMzmHQXh6OOmc4d0j/R0o08f56PGYX/sr2H7yRp11
# LB4nLCbbbxV7HhmLNriT1ObyF5lZynDwN7+YAN8gFk8n+2BnFqFmut1VwDophrCY
# oCvtlUG3OtUVmDG0YgkPCr2B2RP+v6TR81fZvAT6gt4y3wSJ8ADNXcL50CN/AAvk
# dgIm2fBldkKmKYcJRyvmfxqkhQ/8mJb2VVQrH4D6wPIOK+XW+6kvRBVK5xMOHds3
# OBqhK/bt1nz8MIIFjTCCBHWgAwIBAgIQDpsYjvnQLefv21DiCEAYWjANBgkqhkiG
# 9w0BAQwFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkw
# FwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1
# cmVkIElEIFJvb3QgQ0EwHhcNMjIwODAxMDAwMDAwWhcNMzExMTA5MjM1OTU5WjBi
# MQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3
# d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdpQ2VydCBUcnVzdGVkIFJvb3Qg
# RzQwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC/5pBzaN675F1KPDAi
# MGkz7MKnJS7JIT3yithZwuEppz1Yq3aaza57G4QNxDAf8xukOBbrVsaXbR2rsnny
# yhHS5F/WBTxSD1Ifxp4VpX6+n6lXFllVcq9ok3DCsrp1mWpzMpTREEQQLt+C8weE
# 5nQ7bXHiLQwb7iDVySAdYyktzuxeTsiT+CFhmzTrBcZe7FsavOvJz82sNEBfsXpm
# 7nfISKhmV1efVFiODCu3T6cw2Vbuyntd463JT17lNecxy9qTXtyOj4DatpGYQJB5
# w3jHtrHEtWoYOAMQjdjUN6QuBX2I9YI+EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsD
# dV14Ztk6MUSaM0C/CNdaSaTC5qmgZ92kJ7yhTzm1EVgX9yRcRo9k98FpiHaYdj1Z
# XUJ2h4mXaXpI8OCiEhtmmnTK3kse5w5jrubU75KSOp493ADkRSWJtppEGSt+wJS0
# 0mFt6zPZxd9LBADMfRyVw4/3IbKyEbe7f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hk
# pjPRiQfhvbfmQ6QYuKZ3AeEPlAwhHbJUKSWJbOUOUlFHdL4mrLZBdd56rF+NP8m8
# 00ERElvlEFDrMcXKchYiCd98THU/Y+whX8QgUWtvsauGi0/C1kVfnSD8oR7FwI+i
# sX4KJpn15GkvmB0t9dmpsh3lGwIDAQABo4IBOjCCATYwDwYDVR0TAQH/BAUwAwEB
# /zAdBgNVHQ4EFgQU7NfjgtJxXWRM3y5nP+e6mK4cD08wHwYDVR0jBBgwFoAUReui
# r/SSy4IxLVGLp6chnfNtyA8wDgYDVR0PAQH/BAQDAgGGMHkGCCsGAQUFBwEBBG0w
# azAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUF
# BzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVk
# SURSb290Q0EuY3J0MEUGA1UdHwQ+MDwwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2lj
# ZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwEQYDVR0gBAowCDAG
# BgRVHSAAMA0GCSqGSIb3DQEBDAUAA4IBAQBwoL9DXFXnOF+go3QbPbYW1/e/Vwe9
# mqyhhyzshV6pGrsi+IcaaVQi7aSId229GhT0E0p6Ly23OO/0/4C5+KH38nLeJLxS
# A8hO0Cre+i1Wz/n096wwepqLsl7Uz9FDRJtDIeuWcqFItJnLnU+nBgMTdydE1Od/
# 6Fmo8L8vC6bp8jQ87PcDx4eo0kxAGTVGamlUsLihVo7spNU96LHc/RzY9HdaXFSM
# b++hUD38dglohJ9vytsgjTVgHAIDyyCwrFigDkBjxZgiwbJZ9VVrzyerbHbObyMt
# 9H5xaiNrIv8SuFQtJ37YOtnwtoeW/VvRXKwYw02fc7cBqZ9Xql4o4rmUMYIDdjCC
# A3ICAQEwdzBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4x
# OzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGlt
# ZVN0YW1waW5nIENBAhAFRK/zlJ0IOaa/2z9f5WEWMA0GCWCGSAFlAwQCAQUAoIHR
# MBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAcBgkqhkiG9w0BCQUxDxcNMjQw
# MTE4MDkzMjE0WjArBgsqhkiG9w0BCRACDDEcMBowGDAWBBRm8CsywsLJD4JdzqqK
# ycZPGZzPQDAvBgkqhkiG9w0BCQQxIgQgsKVjcWycy/UUm+DuXrE1b/ZA4HSKYEjP
# u6OxjQoM0MswNwYLKoZIhvcNAQkQAi8xKDAmMCQwIgQg0vbkbe10IszR1EBXaEE2
# b4KK2lWarjMWr00amtQMeCgwDQYJKoZIhvcNAQEBBQAEggIAcpJxxIdBErRSSjTe
# cm7V3oeWku+tVoghdX2NmN/tJ5Oz1pqPF+aMvVCeGByJnMbPeWqeNz2JoATTz3fF
# wUc0W8a5ihv0zcspjNkD0JvMQ6KI36Bq1JhzTiObP80leCFNKosPCYcsK8TOsGyH
# r2wsLRwYLOFbTRIbrVEWiivFQAOpifPennswcvmdxuQComr7f4he9qbux2gpaH+s
# 0Da2o6qUwmoIEPIafKDbvkbfRrYV+aqsW5uw7SCVHaMKA/7OlUFm6n1go+pdh54O
# aFsYHKuLSQPCPbuo1NHS5HSsaf0KzPmRE7dJyNX4mbbH3bjsJQ49zva8Frab8iFy
# tE10yITjBoYCsl0JFZtEtCIJuzRXAbc4qjTjzNdJZw8iEkVTDMsskLEIm9arWlmH
# gQuQhdTqVMLSSyXijtjeICiQkBA1Te2qYSlyVDiqANiKhpuJMqIq7sIHJPi/BGQs
# UH9T+CTNu+qZbdSGhNzrkQUGVz9UI99tJThQGfL9hZD6e7lcnBagstJKcYOLmdXY
# 3BZB8cqTzp/Cxu72J2HL2zRkapTuh17lZ1cKtIWxfcjiuRQspRIAuJyjATiU1zQW
# 0ht7p2IQO9pbjHIpbepzXk30CbrgtdNpJt9CvLXndCqCc5wui/vnDXF8/smbvTiO
# /NRKD5nfCFzh9ZpBhjUqIzOtQY0=
# SIG # End signature block
